
import React from 'react';

const Pages = () => {
    return (
        <svg xmlns='http://www.w3.org/2000/svg' fill='currentColor' className='bi bi-file-text-fill sidebar-icon' viewBox='0 0 16 16'>
            <path d='M12 0H4a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h8a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2zM5 4h6a.5.5 0 0 1 0 1H5a.5.5 0 0 1 0-1zm-.5 2.5A.5.5 0 0 1 5 6h6a.5.5 0 0 1 0 1H5a.5.5 0 0 1-.5-.5zM5 8h6a.5.5 0 0 1 0 1H5a.5.5 0 0 1 0-1zm0 2h3a.5.5 0 0 1 0 1H5a.5.5 0 0 1 0-1z' />
        </svg>
    );
};

export default Pages;