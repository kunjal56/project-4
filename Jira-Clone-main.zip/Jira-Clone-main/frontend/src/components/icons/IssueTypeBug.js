import React from 'react';

const IssueTypeBug = ({ style }) => {
    return (

        <svg xmlns='http://www.w3.org/2000/svg' style={style} fill='#e5493a' className='bi bi-exclamation-square-fill' viewBox='0 0 18 18'>
            <path d='M2 0a2 2 0 0 0-2 2v12a2 2 0 0 0 2 2h12a2 2 0 0 0 2-2V2a2 2 0 0 0-2-2H2zm6 4c.535 0 .954.462.9.995l-.35 3.507a.552.552 0 0 1-1.1 0L7.1 4.995A.905.905 0 0 1 8 4zm.002 6a1 1 0 1 1 0 2 1 1 0 0 1 0-2z' />
        </svg>
    );
};

export default IssueTypeBug;